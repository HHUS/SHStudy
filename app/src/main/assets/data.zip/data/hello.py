#coding=utf-8

print('hello,world')

# name = input('please enter your name\n')
# print('hello,',name)

# a = 123 # a是整数
# print(a)
# a = 'ABC' # a变为字符串
# print(a)


# def my_abs(x):

#     if not isinstance(x,(int,float)):
#     	raise TypeError(bad operand type)

# 	if x >= 0:
# 		return x
# 	else:
# 		return -x



# print(my_abs('ssss'))

L = ['sunhao','malan','love']

r = []
for i in xrange(0,2):

	r.append(L[i])

	print(r)